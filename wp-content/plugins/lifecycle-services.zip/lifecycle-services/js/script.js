jQuery(document).ready(function($) {
    if (window.location.pathname === '/services') {
        // Populate the sidebar with initial links
        $('#org-chart-sidebar').html(`
            <ul>
                <li><a href="#" class="active">All Lifecycle Services</a></li>
                <li><a href="#">Advisory</a></li>
                <li><a href="#">Design</a></li>
                <li><a href="#">Implementation</a></li>
                <li><a href="#">Support</a></li>
                <li><a href="#">Assessments</a></li>
                <li><a href="#">Trainings</a></li>
            </ul>
            <div id="select-container">
                <select id="technology">
                    <option value="">Select Technology</option>
                </select>
                <select id="subtechnology">
                    <option value="">Select Subtechnology</option>
                </select>
                <select id="vendor">
                    <option value="">Select Vendor</option>
                </select>
                <select id="product">
                    <option value="">Select Product</option>
                </select>
            </div>
            <div id="card-container"></div>
        `);

        // Fetch data from the internal API
        $.ajax({
            url: '/wp-json/custom/v1/data',
            method: 'GET',
            success: function(response) {
                populateSelectOptions(response);
            },
            error: function(error) {
                console.error('Error fetching data:', error);
            }
        });

        function populateSelectOptions(data) {
            let technologyOptions = '';
            let subtechnologyOptions = '';
            let vendorOptions = '';
            let productOptions = '';

            technologyOptions += `<option value="tech1">Tech1</option>`;
            technologyOptions += `<option value="tech2">Tech2</option>`;

            subtechnologyOptions += `<option value="subtech1">Subtech1</option>`;
            subtechnologyOptions += `<option value="subtech2">Subtech2</option>`;

            vendorOptions += `<option value="vendor1">Vendor1</option>`;
            vendorOptions += `<option value="vendor2">Vendor2</option>`;

            productOptions += `<option value="product1">Product1</option>`;
            productOptions += `<option value="product2">Product2</option>`;

            $('#technology').append(technologyOptions);
            $('#subtechnology').append(subtechnologyOptions);
            $('#vendor').append(vendorOptions);
            $('#product').append(productOptions);
        }

        // Event listener for select options
        $('#technology, #subtechnology, #vendor, #product').change(function() {
            const selectedItems = {
                technology: $('#technology').val(),
                subtechnology: $('#subtechnology').val(),
                vendor: $('#vendor').val(),
                product: $('#product').val()
            };

            // Fetch data based on selected items
            $.ajax({
                url: '/wp-json/custom/v1/data',
                method: 'GET',
                success: function(response) {
                    const filteredData = filterData(response, selectedItems);
                    displayCards(filteredData);
                },
                error: function(error) {
                    console.error('Error fetching filtered data:', error);
                }
            });
        });

        function filterData(data, selectedItems) {
            return data.filter(item => {
                return (selectedItems.technology === '' || item.technology === selectedItems.technology) &&
                       (selectedItems.subtechnology === '' || item.subtechnology === selectedItems.subtechnology) &&
                       (selectedItems.vendor === '' || item.vendor === selectedItems.vendor) &&
                       (selectedItems.product === '' || item.product === selectedItems.product);
            });
        }

        function displayCards(items) {
            let cardContainer = $('#card-container');
            cardContainer.empty();
            items.forEach(item => {
                cardContainer.append(`
                    <div class="card">
                        <h3>${item.title}</h3>
                        <p>${item.description}</p>
                    </div>
                `);
            });
        }
    }


    $('.nav-options').on('click', function () {
        $('.nav-options').removeClass('active')
        $(this).toggleClass('active')
    })

    jQuery(document).ready(function($) {
        if (window.location.pathname === '/services') {
            $('#org-chart-sidebar').html(`
                <ul>
                    <li><a href="#" class="active">All Lifecycle Services</a></li>
                    <li><a href="#">Advisory</a></li>
                    <li><a href="#">Design</a></li>
                    <li><a href="#">Implementation</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">Assessments</a></li>
                    <li><a href="#">Trainings</a></li>
                </ul>
            `);
        }
    });
    
});
